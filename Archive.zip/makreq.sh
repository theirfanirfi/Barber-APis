#!/bin/bash
python3 request.py $1 $2
