<?php
namespace App\Http\MyClasses;
use App\User;

 class VerifyToken {

}
